﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Printing;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace StampanjeNalepnicaV5
{
    ///////////////////////////////////////////////////
    /// Dizajnirao i Programirao David Gvozdenović  ///
    ///////////////////////////////////////////////////
    public partial class MainWindow : Window
    {
        const int SIRINA_A4 = 21;
        const double VISINA_A4 = 29.7;
        double novaSirinaA4, novaVisinaA4;

        double levaMargina, gornjaMargina, desnaMargina, donjaMargina;
        double sirinaNalepnice, visinaNalepnice, razmakVertikalni, razmakHorizontalni;

        double kolicinaNalepnicaPoVisini = 0, kolicinaNalepnicaPoDuzini = 0;
        double privremenaDuzina = 0, privremenaVisina = 0, ukupanBrojNalepnica = 0;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void UnesiVrednostiZa80_Click(object sender, RoutedEventArgs e)
        {
            marginaLeva.Text = "1.01";
            marginaGornja.Text = "1.4";
            nalepnicaSirina.Text = "3.58";
            nalepnicaVisina.Text = "1.67";
            horizontalniRazmak.Text = "0.25";
            vertikalniRazmak.Text = "0";
            velicinaFonta.SelectedIndex = 2;
            sveNalepnice.IsChecked = true;

            prvaNalepnica.IsEnabled = false;
            zadnjaNalepnica.IsEnabled = false;
            prvaNalepnica.Maximum = 80;
            zadnjaNalepnica.Maximum = 80;
            prvaNalepnica.TickFrequency = 1;
            zadnjaNalepnica.TickFrequency = 1;
            zadnjaNalepnica.Value = 80;
        }


        private void SveNalepnice_Checked(object sender, RoutedEventArgs e)
        {

            prvaNalepnica.IsEnabled = false;
            zadnjaNalepnica.IsEnabled = false;
            prvaNalepnica.Value = 0;
            zadnjaNalepnica.Value = 80;
        }
        private void ProizvoljneNalepnice_Checked(object sender, RoutedEventArgs e)
        {
            prvaNalepnica.IsEnabled = true;
            zadnjaNalepnica.IsEnabled = true;

            prvaNalepnica.Value = prvaNalepnica.Minimum;
            zadnjaNalepnica.Value = zadnjaNalepnica.Maximum;

        }
        private void jednaNalepnica_Checked(object sender, RoutedEventArgs e)
        {

            prvaNalepnica.IsEnabled = true;
            zadnjaNalepnica.IsEnabled = false;

            prvaNalepnica.Value = prvaNalepnica.Minimum;
            zadnjaNalepnica.Value = zadnjaNalepnica.Maximum;
        }
        private void saBorderom_Checked(object sender, RoutedEventArgs e)
        {

            saBorderom.IsChecked = true;
            bezBordera.IsChecked = false;
        }
        private void bezBordera_Checked(object sender, RoutedEventArgs e)
        {

            bezBordera.IsChecked = true;
            saBorderom.IsChecked = false;
        }


        private void KolicinaNalepnica_Click(object sender, RoutedEventArgs e)
        {
            double nalepnice_visina = Convert.ToDouble(nalepnicaVisina.Text);
            double nalepnice_duzina = Convert.ToDouble(nalepnicaSirina.Text);

            double margina_leva = Convert.ToDouble(marginaLeva.Text);
            double margina_desna = Convert.ToDouble(marginaDesna.Text);
            double margina_gornja = Convert.ToDouble(marginaGornja.Text);
            double margina_donja = Convert.ToDouble(marginaDonja.Text);

            double horizotalni_razmak = Convert.ToDouble(horizontalniRazmak.Text);
            double vertikalni_razmak = Convert.ToDouble(vertikalniRazmak.Text);

            if (nalepnicaSadrzaj.Text.Length == 0 || nalepnicaVisina.Text == "0" || nalepnicaSirina.Text == "0")
            {
                MessageBox.Show("Sadržaj i dimenzije nalepnice ne mogu biti prazni", "Greška", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else if (nalepnice_duzina > 21 || nalepnice_duzina + margina_leva + margina_desna + horizotalni_razmak > 21)
            {
                MessageBox.Show("Dužina nalepnice sa marginama i horizontalnim razmakom ne može biti šira od A4 papira (21cm)", "Greška", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            else if (nalepnice_visina > 29.7 || nalepnice_visina + margina_gornja + margina_donja + vertikalni_razmak > 29.7)
            {
                MessageBox.Show("Visina nalepnice sa marginama i vertikalnim razmakom ne može biti viša od A4 papira (29.7cm)", "Greška", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                kolicinaNalepnicaPoVisini = 0;
                kolicinaNalepnicaPoDuzini = 0;
                privremenaDuzina = 0;
                privremenaVisina = 0;
                ukupanBrojNalepnica = 0;
                MessageBox.Show("Uspešno ste dodali sadržaj nalepnice!", "Sadržaj nalepnice dodat", MessageBoxButton.OK, MessageBoxImage.Information);
                KolicinaNalepnica();
                eksportPDF.IsEnabled = true;
                stampajPDF.IsEnabled = true;
                sveNalepnice.IsEnabled = true;
                sveNalepnice.IsChecked = true;
                proizvoljneNalepnice.IsEnabled = true;
                saBorderom.IsEnabled = true;
                saBorderom.IsChecked = true;
                bezBordera.IsEnabled = true;
                prvaNalepnica.IsEnabled = true;
                zadnjaNalepnica.IsEnabled = true;
                pregledNalepnica.IsEnabled = true;
                brisanjeInputa.IsEnabled = true;
                prvaNalepnica.Maximum = Convert.ToInt32(ukupanBrojNalepnica);
                zadnjaNalepnica.Maximum = Convert.ToInt32(ukupanBrojNalepnica);
                prvaNalepnica.IsEnabled = false;
                zadnjaNalepnica.IsEnabled = false;
                prvaNalepnica_text.IsEnabled = true;
                zadnjaNalepnica_text.IsEnabled = true;

                jednaNalepnica.IsEnabled = true;
            }
        }
        private void PregledNalepnica_Click(object sender, RoutedEventArgs e)
        {
            if (nalepnicaSirina.Text == "0" || nalepnicaVisina.Text == "0" || nalepnicaSadrzaj.Text == "")
            {
                MessageBox.Show("Unesite dimenzije nalepnica", "Greška", MessageBoxButton.OK, MessageBoxImage.Error);

            }
            else
            {
                SolidColorBrush tamnoPlava = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#2D60C2"));
                SolidColorBrush svetloPlava = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#5088F3"));

                PregledSablonaGrid.Children.Clear();
                PregledSablonaGrid.RowDefinitions.Clear();
                PregledSablonaGrid.ColumnDefinitions.Clear();
                int brojac = 1;
                PregledSablonaGrid.Margin = new Thickness((ConvertCmToPixels(levaMargina) / 2), (ConvertCmToPixels(gornjaMargina) / 2), (ConvertCmToPixels(desnaMargina) / 2), (ConvertCmToPixels(donjaMargina) / 2));
                if (sveNalepnice.IsChecked == true)
                {
                    for (int j = 0; j < kolicinaNalepnicaPoVisini + (kolicinaNalepnicaPoVisini - 1); j++)
                    {
                        //petlja za vertikalni razmak
                        if (j % 2 == 1)
                        {
                            RowDefinition redRazmak = new RowDefinition();
                            redRazmak.Height = new GridLength((ConvertCmToPixels(razmakVertikalni) / 2));
                            PregledSablonaGrid.RowDefinitions.Add(redRazmak);
                        }
                        //petlja za pravljenje redova
                        if (j % 2 == 0)
                        {
                            RowDefinition red = new RowDefinition();
                            red.Height = new GridLength((ConvertCmToPixels(visinaNalepnice) / 2));
                            PregledSablonaGrid.RowDefinitions.Add(red);
                        }



                        for (int i = 0; i < kolicinaNalepnicaPoDuzini + (kolicinaNalepnicaPoDuzini - 1); i++)
                        {
                            //petlja za horizontalni razmak
                            if (i % 2 == 1)
                            {
                                ColumnDefinition kolonaRazmak = new ColumnDefinition();
                                kolonaRazmak.Width = new GridLength((ConvertCmToPixels(razmakHorizontalni) / 2));
                                PregledSablonaGrid.ColumnDefinitions.Add(kolonaRazmak);
                            }


                            //petlja za pravljenje kolona i dugmadi
                            if (i % 2 == 0 && j % 2 == 0)
                            {
                                ColumnDefinition kolona = new ColumnDefinition();
                                kolona.Width = new GridLength((ConvertCmToPixels(sirinaNalepnice) / 2));
                                PregledSablonaGrid.ColumnDefinitions.Add(kolona);


                                //pravljenje izgleda nalepnice
                                Button dugme = new Button();
                                dugme.Background = Brushes.Transparent;
                                dugme.BorderThickness = new Thickness(1);
                                dugme.BorderBrush = tamnoPlava;
                                Grid.SetRow(dugme, j);
                                Grid.SetColumn(dugme, i);
                                PregledSablonaGrid.Children.Add(dugme);


                                Label labela = new Label();
                                labela.HorizontalContentAlignment = HorizontalAlignment.Center;
                                labela.VerticalContentAlignment = VerticalAlignment.Center;
                                Grid.SetRow(labela, j);
                                Grid.SetColumn(labela, i);
                                PregledSablonaGrid.Children.Add(labela);

                                TextBlock tekstLabele = new TextBlock();
                                tekstLabele.TextWrapping = TextWrapping.Wrap;
                                tekstLabele.TextAlignment = TextAlignment.Center;
                                tekstLabele.Text = "Nalepnica " + brojac;
                                tekstLabele.FontSize = 10;
                                tekstLabele.Foreground = tamnoPlava;
                                labela.Content = tekstLabele;
                                brojac++;


                            }

                        }

                    }
                }
                if (proizvoljneNalepnice.IsChecked == true)
                {
                    int prvaNalepnicaKolicina = Convert.ToInt32(prvaNalepnica_text.Text);
                    int zadnjaNalepnicaKolicina = Convert.ToInt32(zadnjaNalepnica_text.Text);

                    if (zadnjaNalepnicaKolicina < prvaNalepnicaKolicina)
                    {
                        MessageBox.Show("Zadnja nalepnica ne može biti pre prve nalepnice", "Greška", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                    else
                    {
                        for (int j = 0; j < kolicinaNalepnicaPoVisini + (kolicinaNalepnicaPoVisini - 1); j++)
                        {
                            //petlja za vertikalni razmak
                            if (j % 2 == 1)
                            {
                                RowDefinition redRazmak = new RowDefinition();
                                redRazmak.Height = new GridLength((ConvertCmToPixels(razmakVertikalni) / 2));
                                PregledSablonaGrid.RowDefinitions.Add(redRazmak);
                            }
                            //petlja za pravljenje redova
                            if (j % 2 == 0)
                            {
                                RowDefinition red = new RowDefinition();
                                red.Height = new GridLength((ConvertCmToPixels(visinaNalepnice) / 2));
                                PregledSablonaGrid.RowDefinitions.Add(red);
                            }



                            for (int i = 0; i < kolicinaNalepnicaPoDuzini + (kolicinaNalepnicaPoDuzini - 1); i++)
                            {

                                //petlja za horizontalni razmak
                                if (i % 2 == 1)
                                {
                                    ColumnDefinition kolonaRazmak = new ColumnDefinition();
                                    kolonaRazmak.Width = new GridLength((ConvertCmToPixels(razmakHorizontalni) / 2));
                                    PregledSablonaGrid.ColumnDefinitions.Add(kolonaRazmak);
                                }


                                //petlja za pravljenje kolona i dugmadi
                                if (i % 2 == 0 && j % 2 == 0)
                                {
                                    ColumnDefinition kolona = new ColumnDefinition();
                                    kolona.Width = new GridLength((ConvertCmToPixels(sirinaNalepnice) / 2));
                                    PregledSablonaGrid.ColumnDefinitions.Add(kolona);



                                    if (brojac >= prvaNalepnicaKolicina && brojac <= zadnjaNalepnicaKolicina)
                                    {
                                        //pravljenje izgleda nalepnice
                                        Button dugme = new Button();
                                        dugme.Background = Brushes.Transparent;
                                        dugme.BorderThickness = new Thickness(1);
                                        dugme.BorderBrush = tamnoPlava;
                                        Grid.SetRow(dugme, j);
                                        Grid.SetColumn(dugme, i);
                                        PregledSablonaGrid.Children.Add(dugme);

                                        Label labela = new Label();
                                        labela.HorizontalContentAlignment = HorizontalAlignment.Center;
                                        labela.VerticalContentAlignment = VerticalAlignment.Center;
                                        Grid.SetRow(labela, j);
                                        Grid.SetColumn(labela, i);
                                        PregledSablonaGrid.Children.Add(labela);

                                        TextBlock tekstLabele = new TextBlock();
                                        tekstLabele.TextWrapping = TextWrapping.Wrap;
                                        tekstLabele.TextAlignment = TextAlignment.Center;
                                        tekstLabele.Text = "Nalepnica " + brojac;
                                        tekstLabele.FontSize = 10;
                                        tekstLabele.Foreground = tamnoPlava;
                                        labela.Content = tekstLabele;


                                    }

                                    brojac++;


                                }

                            }

                        }
                    }



                }
                if (jednaNalepnica.IsChecked == true)
                {
                    int prvaNalepnicaKolicina = Convert.ToInt32(prvaNalepnica_text.Text);
                    for (int j = 0; j < kolicinaNalepnicaPoVisini + (kolicinaNalepnicaPoVisini - 1); j++)
                    {
                        //petlja za vertikalni razmak
                        if (j % 2 == 1)
                        {
                            RowDefinition redRazmak = new RowDefinition();
                            redRazmak.Height = new GridLength((ConvertCmToPixels(razmakVertikalni) / 2));
                            PregledSablonaGrid.RowDefinitions.Add(redRazmak);
                        }
                        //petlja za pravljenje redova
                        if (j % 2 == 0)
                        {
                            RowDefinition red = new RowDefinition();
                            red.Height = new GridLength((ConvertCmToPixels(visinaNalepnice) / 2));
                            PregledSablonaGrid.RowDefinitions.Add(red);
                        }



                        for (int i = 0; i < kolicinaNalepnicaPoDuzini + (kolicinaNalepnicaPoDuzini - 1); i++)
                        {

                            //petlja za horizontalni razmak
                            if (i % 2 == 1)
                            {
                                ColumnDefinition kolonaRazmak = new ColumnDefinition();
                                kolonaRazmak.Width = new GridLength((ConvertCmToPixels(razmakHorizontalni) / 2));
                                PregledSablonaGrid.ColumnDefinitions.Add(kolonaRazmak);
                            }


                            //petlja za pravljenje kolona i dugmadi
                            if (i % 2 == 0 && j % 2 == 0)
                            {
                                ColumnDefinition kolona = new ColumnDefinition();
                                kolona.Width = new GridLength((ConvertCmToPixels(sirinaNalepnice) / 2));
                                PregledSablonaGrid.ColumnDefinitions.Add(kolona);



                                if (brojac == prvaNalepnicaKolicina)
                                {
                                    //pravljenje izgleda nalepnice
                                    Button dugme = new Button();
                                    dugme.Background = Brushes.Transparent;
                                    dugme.BorderThickness = new Thickness(1);
                                    dugme.BorderBrush = tamnoPlava;
                                    Grid.SetRow(dugme, j);
                                    Grid.SetColumn(dugme, i);
                                    PregledSablonaGrid.Children.Add(dugme);

                                    Label labela = new Label();
                                    labela.HorizontalContentAlignment = HorizontalAlignment.Center;
                                    labela.VerticalContentAlignment = VerticalAlignment.Center;
                                    Grid.SetRow(labela, j);
                                    Grid.SetColumn(labela, i);
                                    PregledSablonaGrid.Children.Add(labela);

                                    TextBlock tekstLabele = new TextBlock();
                                    tekstLabele.TextWrapping = TextWrapping.Wrap;
                                    tekstLabele.TextAlignment = TextAlignment.Center;
                                    tekstLabele.Text = "Nalepnica " + brojac;
                                    tekstLabele.FontSize = 10;
                                    tekstLabele.Foreground = tamnoPlava;
                                    labela.Content = tekstLabele;


                                }

                                brojac++;


                            }

                        }

                    }
                }
            }


        }
        private void Obrisi_Click(object sender, RoutedEventArgs e)
        {
            PregledSablonaGrid.Children.Clear();
            PregledSablonaGrid.RowDefinitions.Clear();
            PregledSablonaGrid.ColumnDefinitions.Clear();
            marginaLeva.Text = "0";
            marginaGornja.Text = "0";
            marginaDesna.Text = "0";
            marginaDonja.Text = "0";
            nalepnicaSirina.Text = "0";
            nalepnicaVisina.Text = "0";
            horizontalniRazmak.Text = "0";
            vertikalniRazmak.Text = "0";
            velicinaFonta.SelectedItem = 1;
            nalepnicaSadrzaj.Text = "";


        }



        private void StampajNalepnice_Click(object sender, RoutedEventArgs e)
        {
            if(saBorderom.IsChecked == true)
            {
                if (nalepnicaSirina.Text == "0" || nalepnicaVisina.Text == "0" || nalepnicaSadrzaj.Text == "")
                {
                    MessageBox.Show("Unesite dimenzije nalepnica", "Greška", MessageBoxButton.OK, MessageBoxImage.Error);

                }
                else
                {
                    int brojac = 1;
                    StampanjeSablona stampanjeSablona = new StampanjeSablona();

                    //stavljanje unetih margina na prozor
                    stampanjeSablona.noviSablonGrid.Margin = new Thickness(ConvertCmToPixels(levaMargina), ConvertCmToPixels(gornjaMargina), ConvertCmToPixels(desnaMargina), ConvertCmToPixels(donjaMargina));
                    if (sveNalepnice.IsChecked == true)
                    {
                        for (int j = 0; j < kolicinaNalepnicaPoVisini + (kolicinaNalepnicaPoVisini - 1); j++)
                        {
                            //petlja za vertikalni razmak
                            if (j % 2 == 1)
                            {
                                RowDefinition redRazmak = new RowDefinition();
                                redRazmak.Height = new GridLength(ConvertCmToPixels(razmakVertikalni));
                                stampanjeSablona.noviSablonGrid.RowDefinitions.Add(redRazmak);
                            }
                            //petlja za pravljenje redova
                            if (j % 2 == 0)
                            {
                                RowDefinition red = new RowDefinition();
                                red.Height = new GridLength(ConvertCmToPixels(visinaNalepnice));
                                stampanjeSablona.noviSablonGrid.RowDefinitions.Add(red);
                            }



                            for (int i = 0; i < kolicinaNalepnicaPoDuzini + (kolicinaNalepnicaPoDuzini - 1); i++)
                            {
                                //petlja za horizontalni razmak
                                if (i % 2 == 1)
                                {
                                    ColumnDefinition kolonaRazmak = new ColumnDefinition();
                                    kolonaRazmak.Width = new GridLength(ConvertCmToPixels(razmakHorizontalni));
                                    stampanjeSablona.noviSablonGrid.ColumnDefinitions.Add(kolonaRazmak);
                                }


                                //petlja za pravljenje kolona i dugmadi
                                if (i % 2 == 0 && j % 2 == 0)
                                {
                                    ColumnDefinition kolona = new ColumnDefinition();
                                    kolona.Width = new GridLength(ConvertCmToPixels(sirinaNalepnice));
                                    stampanjeSablona.noviSablonGrid.ColumnDefinitions.Add(kolona);

                                    //String imeNalepnice = "nalepnica" + i;
                                    //pravljenje izgleda nalepnice
                                    Button dugme = new Button();
                                    dugme.Background = Brushes.Transparent;
                                    dugme.BorderThickness = new Thickness(1);
                                    Grid.SetRow(dugme, j);
                                    Grid.SetColumn(dugme, i);
                                    stampanjeSablona.noviSablonGrid.Children.Add(dugme);


                                    Label labela = new Label();
                                    labela.HorizontalContentAlignment = HorizontalAlignment.Center;
                                    labela.VerticalContentAlignment = VerticalAlignment.Center;
                                    Grid.SetRow(labela, j);
                                    Grid.SetColumn(labela, i);
                                    stampanjeSablona.noviSablonGrid.Children.Add(labela);

                                    TextBlock tekstLabele = new TextBlock();
                                    tekstLabele.TextWrapping = TextWrapping.Wrap;
                                    tekstLabele.TextAlignment = TextAlignment.Center;
                                    tekstLabele.Text = nalepnicaSadrzaj.Text;
                                    switch (velicinaFonta.SelectedIndex)
                                    {
                                        case 0:
                                            tekstLabele.FontSize = 12;
                                            break;
                                        case 1:
                                            tekstLabele.FontSize = 14;
                                            break;
                                        case 2:
                                            tekstLabele.FontSize = 16;
                                            break;
                                        case 3:
                                            tekstLabele.FontSize = 18;
                                            break;
                                        case 4:
                                            tekstLabele.FontSize = 20;
                                            break;
                                        case 5:
                                            tekstLabele.FontSize = 22;
                                            break;
                                        case 6:
                                            tekstLabele.FontSize = 24;
                                            break;
                                        case 7:
                                            tekstLabele.FontSize = 26;
                                            break;
                                        case 8:
                                            tekstLabele.FontSize = 28;
                                            break;
                                        case 9:
                                            tekstLabele.FontSize = 30;
                                            break;
                                        case 10:
                                            tekstLabele.FontSize = 32;
                                            break;
                                        case 11:
                                            tekstLabele.FontSize = 34;
                                            break;
                                        case 12:
                                            tekstLabele.FontSize = 36;
                                            break;
                                        case 13:
                                            tekstLabele.FontSize = 38;
                                            break;
                                        case 14:
                                            tekstLabele.FontSize = 40;
                                            break;
                                        case 15:
                                            tekstLabele.FontSize = 42;
                                            break;
                                        case 16:
                                            tekstLabele.FontSize = 44;
                                            break;
                                        case 17:
                                            tekstLabele.FontSize = 46;
                                            break;
                                        case 18:
                                            tekstLabele.FontSize = 48;
                                            break;
                                        case 19:
                                            tekstLabele.FontSize = 50;
                                            break;
                                        case 20:
                                            tekstLabele.FontSize = 52;
                                            break;
                                        case 21:
                                            tekstLabele.FontSize = 54;
                                            break;
                                        case 22:
                                            tekstLabele.FontSize = 56;
                                            break;
                                        case 23:
                                            tekstLabele.FontSize = 58;
                                            break;
                                        case 24:
                                            tekstLabele.FontSize = 60;
                                            break;
                                    }
                                    labela.Content = tekstLabele;



                                }

                            }

                        }

                        //kod za stampapanje i konvertovanje prozora u PDF
                        PrintDialog printDlg = new System.Windows.Controls.PrintDialog();
                        PageMediaSize pageSize = new PageMediaSize(PageMediaSizeName.ISOA4);
                        printDlg.PrintTicket.PageMediaSize = pageSize;
                        if (printDlg.ShowDialog() == true)
                        {
                            printDlg.PrintVisual(stampanjeSablona.noviSablonGrid, "Testiranje");
                        }
                        PrintTicket pt = printDlg.PrintTicket;
                    }
                    if (proizvoljneNalepnice.IsChecked == true)
                    {
                        int prvaNalepnicaKolicina = Convert.ToInt32(prvaNalepnica_text.Text);
                        int zadnjaNalepnicaKolicina = Convert.ToInt32(zadnjaNalepnica_text.Text);

                        if (zadnjaNalepnicaKolicina < prvaNalepnicaKolicina)
                        {
                            MessageBox.Show("Zadnja nalepnica ne može biti pre prve nalepnice", "Greška", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                        else
                        {
                            //MessageBox.Show("Izabrali ste proizvoljnu kolicinu", "Broj btn po visini", MessageBoxButton.OK, MessageBoxImage.Information);
                            //MessageBox.Show(prvaNalepnicaKolicina.ToString(), "Prva nalepnica", MessageBoxButton.OK, MessageBoxImage.Information);
                            //MessageBox.Show(zadnjaNalepnicaKolicina.ToString(), "Zadnja nalepnica", MessageBoxButton.OK, MessageBoxImage.Information);


                            for (int j = 0; j < kolicinaNalepnicaPoVisini + (kolicinaNalepnicaPoVisini - 1); j++)
                            {
                                //petlja za vertikalni razmak
                                if (j % 2 == 1)
                                {
                                    RowDefinition redRazmak = new RowDefinition();
                                    redRazmak.Height = new GridLength(ConvertCmToPixels(razmakVertikalni));
                                    stampanjeSablona.noviSablonGrid.RowDefinitions.Add(redRazmak);
                                }
                                //petlja za pravljenje redova
                                if (j % 2 == 0)
                                {
                                    RowDefinition red = new RowDefinition();
                                    red.Height = new GridLength(ConvertCmToPixels(visinaNalepnice));
                                    stampanjeSablona.noviSablonGrid.RowDefinitions.Add(red);
                                }



                                for (int i = 0; i < kolicinaNalepnicaPoDuzini + (kolicinaNalepnicaPoDuzini - 1); i++)
                                {

                                    //petlja za horizontalni razmak
                                    if (i % 2 == 1)
                                    {
                                        ColumnDefinition kolonaRazmak = new ColumnDefinition();
                                        kolonaRazmak.Width = new GridLength(ConvertCmToPixels(razmakHorizontalni));
                                        stampanjeSablona.noviSablonGrid.ColumnDefinitions.Add(kolonaRazmak);
                                    }


                                    //petlja za pravljenje kolona i dugmadi
                                    if (i % 2 == 0 && j % 2 == 0)
                                    {
                                        ColumnDefinition kolona = new ColumnDefinition();
                                        kolona.Width = new GridLength(ConvertCmToPixels(sirinaNalepnice));
                                        stampanjeSablona.noviSablonGrid.ColumnDefinitions.Add(kolona);


                                        String imeNalepnice = "nalepnica" + brojac;




                                        if (brojac >= prvaNalepnicaKolicina && brojac <= zadnjaNalepnicaKolicina)
                                        {
                                            //pravljenje izgleda nalepnice
                                            Button dugme = new Button();
                                            dugme.Background = Brushes.Transparent;
                                            dugme.BorderThickness = new Thickness(1);
                                            stampanjeSablona.noviSablonGrid.Children.Add(dugme);
                                            Grid.SetRow(dugme, j);
                                            Grid.SetColumn(dugme, i);

                                            Label labela = new Label();
                                            labela.HorizontalContentAlignment = HorizontalAlignment.Center;
                                            labela.VerticalContentAlignment = VerticalAlignment.Center;
                                            stampanjeSablona.noviSablonGrid.Children.Add(labela);
                                            Grid.SetRow(labela, j);
                                            Grid.SetColumn(labela, i);

                                            TextBlock tekstLabele = new TextBlock();
                                            tekstLabele.TextWrapping = TextWrapping.Wrap;
                                            tekstLabele.TextAlignment = TextAlignment.Center;
                                            tekstLabele.Text = nalepnicaSadrzaj.Text;

                                            switch (velicinaFonta.SelectedIndex)
                                            {
                                                case 0:
                                                    tekstLabele.FontSize = 12;
                                                    break;
                                                case 1:
                                                    tekstLabele.FontSize = 14;
                                                    break;
                                                case 2:
                                                    tekstLabele.FontSize = 16;
                                                    break;
                                                case 3:
                                                    tekstLabele.FontSize = 18;
                                                    break;
                                                case 4:
                                                    tekstLabele.FontSize = 20;
                                                    break;
                                                case 5:
                                                    tekstLabele.FontSize = 22;
                                                    break;
                                                case 6:
                                                    tekstLabele.FontSize = 24;
                                                    break;
                                                case 7:
                                                    tekstLabele.FontSize = 26;
                                                    break;
                                                case 8:
                                                    tekstLabele.FontSize = 28;
                                                    break;
                                                case 9:
                                                    tekstLabele.FontSize = 30;
                                                    break;
                                                case 10:
                                                    tekstLabele.FontSize = 32;
                                                    break;
                                                case 11:
                                                    tekstLabele.FontSize = 34;
                                                    break;
                                                case 12:
                                                    tekstLabele.FontSize = 36;
                                                    break;
                                                case 13:
                                                    tekstLabele.FontSize = 38;
                                                    break;
                                                case 14:
                                                    tekstLabele.FontSize = 40;
                                                    break;
                                                case 15:
                                                    tekstLabele.FontSize = 42;
                                                    break;
                                                case 16:
                                                    tekstLabele.FontSize = 44;
                                                    break;
                                                case 17:
                                                    tekstLabele.FontSize = 46;
                                                    break;
                                                case 18:
                                                    tekstLabele.FontSize = 48;
                                                    break;
                                                case 19:
                                                    tekstLabele.FontSize = 50;
                                                    break;
                                                case 20:
                                                    tekstLabele.FontSize = 52;
                                                    break;
                                                case 21:
                                                    tekstLabele.FontSize = 54;
                                                    break;
                                                case 22:
                                                    tekstLabele.FontSize = 56;
                                                    break;
                                                case 23:
                                                    tekstLabele.FontSize = 58;
                                                    break;
                                                case 24:
                                                    tekstLabele.FontSize = 60;
                                                    break;
                                            }
                                            labela.Content = tekstLabele;


                                        }

                                        brojac++;


                                    }

                                }

                            }

                            //kod za stampapanje i konvertovanje prozora u PDF
                            PrintDialog printDlg = new System.Windows.Controls.PrintDialog();
                            PageMediaSize pageSize = new PageMediaSize(PageMediaSizeName.ISOA4);
                            printDlg.PrintTicket.PageMediaSize = pageSize;
                            if (printDlg.ShowDialog() == true)
                            {
                                printDlg.PrintVisual(stampanjeSablona.noviSablonGrid, "Testiranje");
                            }
                            PrintTicket pt = printDlg.PrintTicket;
                        }



                    }
                    if (jednaNalepnica.IsChecked == true)
                    {
                        int prvaNalepnicaKolicina = Convert.ToInt32(prvaNalepnica_text.Text);
                        for (int j = 0; j < kolicinaNalepnicaPoVisini + (kolicinaNalepnicaPoVisini - 1); j++)
                        {
                            //petlja za vertikalni razmak
                            if (j % 2 == 1)
                            {
                                RowDefinition redRazmak = new RowDefinition();
                                redRazmak.Height = new GridLength(ConvertCmToPixels(razmakVertikalni));
                                stampanjeSablona.noviSablonGrid.RowDefinitions.Add(redRazmak);
                            }
                            //petlja za pravljenje redova
                            if (j % 2 == 0)
                            {
                                RowDefinition red = new RowDefinition();
                                red.Height = new GridLength(ConvertCmToPixels(visinaNalepnice));
                                stampanjeSablona.noviSablonGrid.RowDefinitions.Add(red);
                            }



                            for (int i = 0; i < kolicinaNalepnicaPoDuzini + (kolicinaNalepnicaPoDuzini - 1); i++)
                            {

                                //petlja za horizontalni razmak
                                if (i % 2 == 1)
                                {
                                    ColumnDefinition kolonaRazmak = new ColumnDefinition();
                                    kolonaRazmak.Width = new GridLength(ConvertCmToPixels(razmakHorizontalni));
                                    stampanjeSablona.noviSablonGrid.ColumnDefinitions.Add(kolonaRazmak);
                                }


                                //petlja za pravljenje kolona i dugmadi
                                if (i % 2 == 0 && j % 2 == 0)
                                {
                                    ColumnDefinition kolona = new ColumnDefinition();
                                    kolona.Width = new GridLength(ConvertCmToPixels(sirinaNalepnice));
                                    stampanjeSablona.noviSablonGrid.ColumnDefinitions.Add(kolona);


                                    String imeNalepnice = "nalepnica" + brojac;




                                    if (brojac == prvaNalepnicaKolicina)
                                    {
                                        //pravljenje izgleda nalepnice
                                        Button dugme = new Button();
                                        dugme.Background = Brushes.Transparent;
                                        dugme.BorderThickness = new Thickness(1);
                                        stampanjeSablona.noviSablonGrid.Children.Add(dugme);
                                        Grid.SetRow(dugme, j);
                                        Grid.SetColumn(dugme, i);

                                        Label labela = new Label();
                                        labela.HorizontalContentAlignment = HorizontalAlignment.Center;
                                        labela.VerticalContentAlignment = VerticalAlignment.Center;
                                        stampanjeSablona.noviSablonGrid.Children.Add(labela);
                                        Grid.SetRow(labela, j);
                                        Grid.SetColumn(labela, i);

                                        TextBlock tekstLabele = new TextBlock();
                                        tekstLabele.TextWrapping = TextWrapping.Wrap;
                                        tekstLabele.TextAlignment = TextAlignment.Center;
                                        tekstLabele.Text = nalepnicaSadrzaj.Text;

                                        switch (velicinaFonta.SelectedIndex)
                                        {
                                            case 0:
                                                tekstLabele.FontSize = 12;
                                                break;
                                            case 1:
                                                tekstLabele.FontSize = 14;
                                                break;
                                            case 2:
                                                tekstLabele.FontSize = 16;
                                                break;
                                            case 3:
                                                tekstLabele.FontSize = 18;
                                                break;
                                            case 4:
                                                tekstLabele.FontSize = 20;
                                                break;
                                            case 5:
                                                tekstLabele.FontSize = 22;
                                                break;
                                            case 6:
                                                tekstLabele.FontSize = 24;
                                                break;
                                            case 7:
                                                tekstLabele.FontSize = 26;
                                                break;
                                            case 8:
                                                tekstLabele.FontSize = 28;
                                                break;
                                            case 9:
                                                tekstLabele.FontSize = 30;
                                                break;
                                            case 10:
                                                tekstLabele.FontSize = 32;
                                                break;
                                            case 11:
                                                tekstLabele.FontSize = 34;
                                                break;
                                            case 12:
                                                tekstLabele.FontSize = 36;
                                                break;
                                            case 13:
                                                tekstLabele.FontSize = 38;
                                                break;
                                            case 14:
                                                tekstLabele.FontSize = 40;
                                                break;
                                            case 15:
                                                tekstLabele.FontSize = 42;
                                                break;
                                            case 16:
                                                tekstLabele.FontSize = 44;
                                                break;
                                            case 17:
                                                tekstLabele.FontSize = 46;
                                                break;
                                            case 18:
                                                tekstLabele.FontSize = 48;
                                                break;
                                            case 19:
                                                tekstLabele.FontSize = 50;
                                                break;
                                            case 20:
                                                tekstLabele.FontSize = 52;
                                                break;
                                            case 21:
                                                tekstLabele.FontSize = 54;
                                                break;
                                            case 22:
                                                tekstLabele.FontSize = 56;
                                                break;
                                            case 23:
                                                tekstLabele.FontSize = 58;
                                                break;
                                            case 24:
                                                tekstLabele.FontSize = 60;
                                                break;
                                        }
                                        labela.Content = tekstLabele;


                                    }

                                    brojac++;


                                }

                            }

                        }

                        //kod za stampapanje i konvertovanje prozora u PDF
                        PrintDialog printDlg = new System.Windows.Controls.PrintDialog();
                        PageMediaSize pageSize = new PageMediaSize(PageMediaSizeName.ISOA4);
                        printDlg.PrintTicket.PageMediaSize = pageSize;
                        if (printDlg.ShowDialog() == true)
                        {
                            printDlg.PrintVisual(stampanjeSablona.noviSablonGrid, "Testiranje");
                        }
                        PrintTicket pt = printDlg.PrintTicket;
                    }
                }
            }
            else
            {
                if (nalepnicaSirina.Text == "0" || nalepnicaVisina.Text == "0" || nalepnicaSadrzaj.Text == "")
                {
                    MessageBox.Show("Unesite dimenzije nalepnica", "Greška", MessageBoxButton.OK, MessageBoxImage.Error);

                }
                else
                {
                    int brojac = 1;
                    StampanjeSablona stampanjeSablona = new StampanjeSablona();

                    //stavljanje unetih margina na prozor
                    stampanjeSablona.noviSablonGrid.Margin = new Thickness(ConvertCmToPixels(levaMargina), ConvertCmToPixels(gornjaMargina), ConvertCmToPixels(desnaMargina), ConvertCmToPixels(donjaMargina));
                    if (sveNalepnice.IsChecked == true)
                    {
                        for (int j = 0; j < kolicinaNalepnicaPoVisini + (kolicinaNalepnicaPoVisini - 1); j++)
                        {
                            //petlja za vertikalni razmak
                            if (j % 2 == 1)
                            {
                                RowDefinition redRazmak = new RowDefinition();
                                redRazmak.Height = new GridLength(ConvertCmToPixels(razmakVertikalni));
                                stampanjeSablona.noviSablonGrid.RowDefinitions.Add(redRazmak);
                            }
                            //petlja za pravljenje redova
                            if (j % 2 == 0)
                            {
                                RowDefinition red = new RowDefinition();
                                red.Height = new GridLength(ConvertCmToPixels(visinaNalepnice));
                                stampanjeSablona.noviSablonGrid.RowDefinitions.Add(red);
                            }



                            for (int i = 0; i < kolicinaNalepnicaPoDuzini + (kolicinaNalepnicaPoDuzini - 1); i++)
                            {
                                //petlja za horizontalni razmak
                                if (i % 2 == 1)
                                {
                                    ColumnDefinition kolonaRazmak = new ColumnDefinition();
                                    kolonaRazmak.Width = new GridLength(ConvertCmToPixels(razmakHorizontalni));
                                    stampanjeSablona.noviSablonGrid.ColumnDefinitions.Add(kolonaRazmak);
                                }


                                //petlja za pravljenje kolona i dugmadi
                                if (i % 2 == 0 && j % 2 == 0)
                                {
                                    ColumnDefinition kolona = new ColumnDefinition();
                                    kolona.Width = new GridLength(ConvertCmToPixels(sirinaNalepnice));
                                    stampanjeSablona.noviSablonGrid.ColumnDefinitions.Add(kolona);

                                    //String imeNalepnice = "nalepnica" + i;
                                    //pravljenje izgleda nalepnice
                                    Button dugme = new Button();
                                    dugme.Background = Brushes.Transparent;
                                    dugme.BorderBrush = Brushes.Transparent;
                                    Grid.SetRow(dugme, j);
                                    Grid.SetColumn(dugme, i);
                                    stampanjeSablona.noviSablonGrid.Children.Add(dugme);


                                    Label labela = new Label();
                                    labela.HorizontalContentAlignment = HorizontalAlignment.Center;
                                    labela.VerticalContentAlignment = VerticalAlignment.Center;
                                    Grid.SetRow(labela, j);
                                    Grid.SetColumn(labela, i);
                                    stampanjeSablona.noviSablonGrid.Children.Add(labela);

                                    TextBlock tekstLabele = new TextBlock();
                                    tekstLabele.TextWrapping = TextWrapping.Wrap;
                                    tekstLabele.TextAlignment = TextAlignment.Center;
                                    tekstLabele.Text = nalepnicaSadrzaj.Text;
                                    switch (velicinaFonta.SelectedIndex)
                                    {
                                        case 0:
                                            tekstLabele.FontSize = 12;
                                            break;
                                        case 1:
                                            tekstLabele.FontSize = 14;
                                            break;
                                        case 2:
                                            tekstLabele.FontSize = 16;
                                            break;
                                        case 3:
                                            tekstLabele.FontSize = 18;
                                            break;
                                        case 4:
                                            tekstLabele.FontSize = 20;
                                            break;
                                        case 5:
                                            tekstLabele.FontSize = 22;
                                            break;
                                        case 6:
                                            tekstLabele.FontSize = 24;
                                            break;
                                        case 7:
                                            tekstLabele.FontSize = 26;
                                            break;
                                        case 8:
                                            tekstLabele.FontSize = 28;
                                            break;
                                        case 9:
                                            tekstLabele.FontSize = 30;
                                            break;
                                        case 10:
                                            tekstLabele.FontSize = 32;
                                            break;
                                        case 11:
                                            tekstLabele.FontSize = 34;
                                            break;
                                        case 12:
                                            tekstLabele.FontSize = 36;
                                            break;
                                        case 13:
                                            tekstLabele.FontSize = 38;
                                            break;
                                        case 14:
                                            tekstLabele.FontSize = 40;
                                            break;
                                        case 15:
                                            tekstLabele.FontSize = 42;
                                            break;
                                        case 16:
                                            tekstLabele.FontSize = 44;
                                            break;
                                        case 17:
                                            tekstLabele.FontSize = 46;
                                            break;
                                        case 18:
                                            tekstLabele.FontSize = 48;
                                            break;
                                        case 19:
                                            tekstLabele.FontSize = 50;
                                            break;
                                        case 20:
                                            tekstLabele.FontSize = 52;
                                            break;
                                        case 21:
                                            tekstLabele.FontSize = 54;
                                            break;
                                        case 22:
                                            tekstLabele.FontSize = 56;
                                            break;
                                        case 23:
                                            tekstLabele.FontSize = 58;
                                            break;
                                        case 24:
                                            tekstLabele.FontSize = 60;
                                            break;
                                    }
                                    labela.Content = tekstLabele;



                                }

                            }

                        }

                        //kod za stampapanje i konvertovanje prozora u PDF
                        PrintDialog printDlg = new System.Windows.Controls.PrintDialog();
                        PageMediaSize pageSize = new PageMediaSize(PageMediaSizeName.ISOA4);
                        printDlg.PrintTicket.PageMediaSize = pageSize;
                        if (printDlg.ShowDialog() == true)
                        {
                            printDlg.PrintVisual(stampanjeSablona.noviSablonGrid, "Testiranje");
                        }
                        PrintTicket pt = printDlg.PrintTicket;
                    }
                    if (proizvoljneNalepnice.IsChecked == true)
                    {
                        int prvaNalepnicaKolicina = Convert.ToInt32(prvaNalepnica_text.Text);
                        int zadnjaNalepnicaKolicina = Convert.ToInt32(zadnjaNalepnica_text.Text);

                        if (zadnjaNalepnicaKolicina < prvaNalepnicaKolicina)
                        {
                            MessageBox.Show("Zadnja nalepnica ne može biti pre prve nalepnice", "Greška", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                        else
                        {
                            //MessageBox.Show("Izabrali ste proizvoljnu kolicinu", "Broj btn po visini", MessageBoxButton.OK, MessageBoxImage.Information);
                            //MessageBox.Show(prvaNalepnicaKolicina.ToString(), "Prva nalepnica", MessageBoxButton.OK, MessageBoxImage.Information);
                            //MessageBox.Show(zadnjaNalepnicaKolicina.ToString(), "Zadnja nalepnica", MessageBoxButton.OK, MessageBoxImage.Information);


                            for (int j = 0; j < kolicinaNalepnicaPoVisini + (kolicinaNalepnicaPoVisini - 1); j++)
                            {
                                //petlja za vertikalni razmak
                                if (j % 2 == 1)
                                {
                                    RowDefinition redRazmak = new RowDefinition();
                                    redRazmak.Height = new GridLength(ConvertCmToPixels(razmakVertikalni));
                                    stampanjeSablona.noviSablonGrid.RowDefinitions.Add(redRazmak);
                                }
                                //petlja za pravljenje redova
                                if (j % 2 == 0)
                                {
                                    RowDefinition red = new RowDefinition();
                                    red.Height = new GridLength(ConvertCmToPixels(visinaNalepnice));
                                    stampanjeSablona.noviSablonGrid.RowDefinitions.Add(red);
                                }



                                for (int i = 0; i < kolicinaNalepnicaPoDuzini + (kolicinaNalepnicaPoDuzini - 1); i++)
                                {

                                    //petlja za horizontalni razmak
                                    if (i % 2 == 1)
                                    {
                                        ColumnDefinition kolonaRazmak = new ColumnDefinition();
                                        kolonaRazmak.Width = new GridLength(ConvertCmToPixels(razmakHorizontalni));
                                        stampanjeSablona.noviSablonGrid.ColumnDefinitions.Add(kolonaRazmak);
                                    }


                                    //petlja za pravljenje kolona i dugmadi
                                    if (i % 2 == 0 && j % 2 == 0)
                                    {
                                        ColumnDefinition kolona = new ColumnDefinition();
                                        kolona.Width = new GridLength(ConvertCmToPixels(sirinaNalepnice));
                                        stampanjeSablona.noviSablonGrid.ColumnDefinitions.Add(kolona);


                                        String imeNalepnice = "nalepnica" + brojac;




                                        if (brojac >= prvaNalepnicaKolicina && brojac <= zadnjaNalepnicaKolicina)
                                        {
                                            //pravljenje izgleda nalepnice
                                            Button dugme = new Button();
                                            dugme.Background = Brushes.Transparent;
                                            dugme.BorderBrush = Brushes.Transparent;
                                            stampanjeSablona.noviSablonGrid.Children.Add(dugme);
                                            Grid.SetRow(dugme, j);
                                            Grid.SetColumn(dugme, i);

                                            Label labela = new Label();
                                            labela.HorizontalContentAlignment = HorizontalAlignment.Center;
                                            labela.VerticalContentAlignment = VerticalAlignment.Center;
                                            stampanjeSablona.noviSablonGrid.Children.Add(labela);
                                            Grid.SetRow(labela, j);
                                            Grid.SetColumn(labela, i);

                                            TextBlock tekstLabele = new TextBlock();
                                            tekstLabele.TextWrapping = TextWrapping.Wrap;
                                            tekstLabele.TextAlignment = TextAlignment.Center;
                                            tekstLabele.Text = nalepnicaSadrzaj.Text;

                                            switch (velicinaFonta.SelectedIndex)
                                            {
                                                case 0:
                                                    tekstLabele.FontSize = 12;
                                                    break;
                                                case 1:
                                                    tekstLabele.FontSize = 14;
                                                    break;
                                                case 2:
                                                    tekstLabele.FontSize = 16;
                                                    break;
                                                case 3:
                                                    tekstLabele.FontSize = 18;
                                                    break;
                                                case 4:
                                                    tekstLabele.FontSize = 20;
                                                    break;
                                                case 5:
                                                    tekstLabele.FontSize = 22;
                                                    break;
                                                case 6:
                                                    tekstLabele.FontSize = 24;
                                                    break;
                                                case 7:
                                                    tekstLabele.FontSize = 26;
                                                    break;
                                                case 8:
                                                    tekstLabele.FontSize = 28;
                                                    break;
                                                case 9:
                                                    tekstLabele.FontSize = 30;
                                                    break;
                                                case 10:
                                                    tekstLabele.FontSize = 32;
                                                    break;
                                                case 11:
                                                    tekstLabele.FontSize = 34;
                                                    break;
                                                case 12:
                                                    tekstLabele.FontSize = 36;
                                                    break;
                                                case 13:
                                                    tekstLabele.FontSize = 38;
                                                    break;
                                                case 14:
                                                    tekstLabele.FontSize = 40;
                                                    break;
                                                case 15:
                                                    tekstLabele.FontSize = 42;
                                                    break;
                                                case 16:
                                                    tekstLabele.FontSize = 44;
                                                    break;
                                                case 17:
                                                    tekstLabele.FontSize = 46;
                                                    break;
                                                case 18:
                                                    tekstLabele.FontSize = 48;
                                                    break;
                                                case 19:
                                                    tekstLabele.FontSize = 50;
                                                    break;
                                                case 20:
                                                    tekstLabele.FontSize = 52;
                                                    break;
                                                case 21:
                                                    tekstLabele.FontSize = 54;
                                                    break;
                                                case 22:
                                                    tekstLabele.FontSize = 56;
                                                    break;
                                                case 23:
                                                    tekstLabele.FontSize = 58;
                                                    break;
                                                case 24:
                                                    tekstLabele.FontSize = 60;
                                                    break;
                                            }
                                            labela.Content = tekstLabele;


                                        }

                                        brojac++;


                                    }

                                }

                            }

                            //kod za stampapanje i konvertovanje prozora u PDF
                            PrintDialog printDlg = new System.Windows.Controls.PrintDialog();
                            PageMediaSize pageSize = new PageMediaSize(PageMediaSizeName.ISOA4);
                            printDlg.PrintTicket.PageMediaSize = pageSize;
                            if (printDlg.ShowDialog() == true)
                            {
                                printDlg.PrintVisual(stampanjeSablona.noviSablonGrid, "Testiranje");
                            }
                            PrintTicket pt = printDlg.PrintTicket;
                        }



                    }
                    if (jednaNalepnica.IsChecked == true)
                    {
                        int prvaNalepnicaKolicina = Convert.ToInt32(prvaNalepnica_text.Text);
                        for (int j = 0; j < kolicinaNalepnicaPoVisini + (kolicinaNalepnicaPoVisini - 1); j++)
                        {
                            //petlja za vertikalni razmak
                            if (j % 2 == 1)
                            {
                                RowDefinition redRazmak = new RowDefinition();
                                redRazmak.Height = new GridLength(ConvertCmToPixels(razmakVertikalni));
                                stampanjeSablona.noviSablonGrid.RowDefinitions.Add(redRazmak);
                            }
                            //petlja za pravljenje redova
                            if (j % 2 == 0)
                            {
                                RowDefinition red = new RowDefinition();
                                red.Height = new GridLength(ConvertCmToPixels(visinaNalepnice));
                                stampanjeSablona.noviSablonGrid.RowDefinitions.Add(red);
                            }



                            for (int i = 0; i < kolicinaNalepnicaPoDuzini + (kolicinaNalepnicaPoDuzini - 1); i++)
                            {

                                //petlja za horizontalni razmak
                                if (i % 2 == 1)
                                {
                                    ColumnDefinition kolonaRazmak = new ColumnDefinition();
                                    kolonaRazmak.Width = new GridLength(ConvertCmToPixels(razmakHorizontalni));
                                    stampanjeSablona.noviSablonGrid.ColumnDefinitions.Add(kolonaRazmak);
                                }


                                //petlja za pravljenje kolona i dugmadi
                                if (i % 2 == 0 && j % 2 == 0)
                                {
                                    ColumnDefinition kolona = new ColumnDefinition();
                                    kolona.Width = new GridLength(ConvertCmToPixels(sirinaNalepnice));
                                    stampanjeSablona.noviSablonGrid.ColumnDefinitions.Add(kolona);


                                    String imeNalepnice = "nalepnica" + brojac;




                                    if (brojac == prvaNalepnicaKolicina)
                                    {
                                        //pravljenje izgleda nalepnice
                                        Button dugme = new Button();
                                        dugme.Background = Brushes.Transparent;
                                        dugme.BorderBrush = Brushes.Transparent;
                                        stampanjeSablona.noviSablonGrid.Children.Add(dugme);
                                        Grid.SetRow(dugme, j);
                                        Grid.SetColumn(dugme, i);

                                        Label labela = new Label();
                                        labela.HorizontalContentAlignment = HorizontalAlignment.Center;
                                        labela.VerticalContentAlignment = VerticalAlignment.Center;
                                        stampanjeSablona.noviSablonGrid.Children.Add(labela);
                                        Grid.SetRow(labela, j);
                                        Grid.SetColumn(labela, i);

                                        TextBlock tekstLabele = new TextBlock();
                                        tekstLabele.TextWrapping = TextWrapping.Wrap;
                                        tekstLabele.TextAlignment = TextAlignment.Center;
                                        tekstLabele.Text = nalepnicaSadrzaj.Text;

                                        switch (velicinaFonta.SelectedIndex)
                                        {
                                            case 0:
                                                tekstLabele.FontSize = 12;
                                                break;
                                            case 1:
                                                tekstLabele.FontSize = 14;
                                                break;
                                            case 2:
                                                tekstLabele.FontSize = 16;
                                                break;
                                            case 3:
                                                tekstLabele.FontSize = 18;
                                                break;
                                            case 4:
                                                tekstLabele.FontSize = 20;
                                                break;
                                            case 5:
                                                tekstLabele.FontSize = 22;
                                                break;
                                            case 6:
                                                tekstLabele.FontSize = 24;
                                                break;
                                            case 7:
                                                tekstLabele.FontSize = 26;
                                                break;
                                            case 8:
                                                tekstLabele.FontSize = 28;
                                                break;
                                            case 9:
                                                tekstLabele.FontSize = 30;
                                                break;
                                            case 10:
                                                tekstLabele.FontSize = 32;
                                                break;
                                            case 11:
                                                tekstLabele.FontSize = 34;
                                                break;
                                            case 12:
                                                tekstLabele.FontSize = 36;
                                                break;
                                            case 13:
                                                tekstLabele.FontSize = 38;
                                                break;
                                            case 14:
                                                tekstLabele.FontSize = 40;
                                                break;
                                            case 15:
                                                tekstLabele.FontSize = 42;
                                                break;
                                            case 16:
                                                tekstLabele.FontSize = 44;
                                                break;
                                            case 17:
                                                tekstLabele.FontSize = 46;
                                                break;
                                            case 18:
                                                tekstLabele.FontSize = 48;
                                                break;
                                            case 19:
                                                tekstLabele.FontSize = 50;
                                                break;
                                            case 20:
                                                tekstLabele.FontSize = 52;
                                                break;
                                            case 21:
                                                tekstLabele.FontSize = 54;
                                                break;
                                            case 22:
                                                tekstLabele.FontSize = 56;
                                                break;
                                            case 23:
                                                tekstLabele.FontSize = 58;
                                                break;
                                            case 24:
                                                tekstLabele.FontSize = 60;
                                                break;
                                        }
                                        labela.Content = tekstLabele;


                                    }

                                    brojac++;


                                }

                            }

                        }

                        //kod za stampapanje i konvertovanje prozora u PDF
                        PrintDialog printDlg = new System.Windows.Controls.PrintDialog();
                        PageMediaSize pageSize = new PageMediaSize(PageMediaSizeName.ISOA4);
                        printDlg.PrintTicket.PageMediaSize = pageSize;
                        if (printDlg.ShowDialog() == true)
                        {
                            printDlg.PrintVisual(stampanjeSablona.noviSablonGrid, "Testiranje");
                        }
                        PrintTicket pt = printDlg.PrintTicket;
                    }
                }
            }
        }
        private void EksportPDF_Click(object sender, RoutedEventArgs e)
        {
            if (saBorderom.IsChecked == true)
            {
                if (nalepnicaSirina.Text == "0" || nalepnicaVisina.Text == "0" || nalepnicaSadrzaj.Text == "")
                {
                    MessageBox.Show("Unesite dimenzije nalepnica", "Greška", MessageBoxButton.OK, MessageBoxImage.Error);

                }
                else
                {
                    int brojac = 1;
                    StampanjeSablona stampanjeSablona = new StampanjeSablona();

                    //stavljanje unetih margina na prozor
                    stampanjeSablona.noviSablonGrid.Margin = new Thickness(ConvertCmToPixels(levaMargina), ConvertCmToPixels(gornjaMargina), ConvertCmToPixels(desnaMargina), ConvertCmToPixels(donjaMargina));
                    if (sveNalepnice.IsChecked == true)
                    {
                        for (int j = 0; j < kolicinaNalepnicaPoVisini + (kolicinaNalepnicaPoVisini - 1); j++)
                        {
                            //petlja za vertikalni razmak
                            if (j % 2 == 1)
                            {
                                RowDefinition redRazmak = new RowDefinition();
                                redRazmak.Height = new GridLength(ConvertCmToPixels(razmakVertikalni));
                                stampanjeSablona.noviSablonGrid.RowDefinitions.Add(redRazmak);
                            }
                            //petlja za pravljenje redova
                            if (j % 2 == 0)
                            {
                                RowDefinition red = new RowDefinition();
                                red.Height = new GridLength(ConvertCmToPixels(visinaNalepnice));
                                stampanjeSablona.noviSablonGrid.RowDefinitions.Add(red);
                            }



                            for (int i = 0; i < kolicinaNalepnicaPoDuzini + (kolicinaNalepnicaPoDuzini - 1); i++)
                            {
                                //petlja za horizontalni razmak
                                if (i % 2 == 1)
                                {
                                    ColumnDefinition kolonaRazmak = new ColumnDefinition();
                                    kolonaRazmak.Width = new GridLength(ConvertCmToPixels(razmakHorizontalni));
                                    stampanjeSablona.noviSablonGrid.ColumnDefinitions.Add(kolonaRazmak);
                                }


                                //petlja za pravljenje kolona i dugmadi
                                if (i % 2 == 0 && j % 2 == 0)
                                {
                                    ColumnDefinition kolona = new ColumnDefinition();
                                    kolona.Width = new GridLength(ConvertCmToPixels(sirinaNalepnice));
                                    stampanjeSablona.noviSablonGrid.ColumnDefinitions.Add(kolona);

                                    //String imeNalepnice = "nalepnica" + i;
                                    //pravljenje izgleda nalepnice
                                    Button dugme = new Button();
                                    dugme.Background = Brushes.Transparent;
                                    dugme.BorderThickness = new Thickness(1);
                                    Grid.SetRow(dugme, j);
                                    Grid.SetColumn(dugme, i);
                                    stampanjeSablona.noviSablonGrid.Children.Add(dugme);


                                    Label labela = new Label();
                                    labela.HorizontalContentAlignment = HorizontalAlignment.Center;
                                    labela.VerticalContentAlignment = VerticalAlignment.Center;
                                    Grid.SetRow(labela, j);
                                    Grid.SetColumn(labela, i);
                                    stampanjeSablona.noviSablonGrid.Children.Add(labela);

                                    TextBlock tekstLabele = new TextBlock();
                                    tekstLabele.TextWrapping = TextWrapping.Wrap;
                                    tekstLabele.TextAlignment = TextAlignment.Center;
                                    tekstLabele.Text = nalepnicaSadrzaj.Text;
                                    switch (velicinaFonta.SelectedIndex)
                                    {
                                        case 0:
                                            tekstLabele.FontSize = 12;
                                            break;
                                        case 1:
                                            tekstLabele.FontSize = 14;
                                            break;
                                        case 2:
                                            tekstLabele.FontSize = 16;
                                            break;
                                        case 3:
                                            tekstLabele.FontSize = 18;
                                            break;
                                        case 4:
                                            tekstLabele.FontSize = 20;
                                            break;
                                        case 5:
                                            tekstLabele.FontSize = 22;
                                            break;
                                        case 6:
                                            tekstLabele.FontSize = 24;
                                            break;
                                        case 7:
                                            tekstLabele.FontSize = 26;
                                            break;
                                        case 8:
                                            tekstLabele.FontSize = 28;
                                            break;
                                        case 9:
                                            tekstLabele.FontSize = 30;
                                            break;
                                        case 10:
                                            tekstLabele.FontSize = 32;
                                            break;
                                        case 11:
                                            tekstLabele.FontSize = 34;
                                            break;
                                        case 12:
                                            tekstLabele.FontSize = 36;
                                            break;
                                        case 13:
                                            tekstLabele.FontSize = 38;
                                            break;
                                        case 14:
                                            tekstLabele.FontSize = 40;
                                            break;
                                        case 15:
                                            tekstLabele.FontSize = 42;
                                            break;
                                        case 16:
                                            tekstLabele.FontSize = 44;
                                            break;
                                        case 17:
                                            tekstLabele.FontSize = 46;
                                            break;
                                        case 18:
                                            tekstLabele.FontSize = 48;
                                            break;
                                        case 19:
                                            tekstLabele.FontSize = 50;
                                            break;
                                        case 20:
                                            tekstLabele.FontSize = 52;
                                            break;
                                        case 21:
                                            tekstLabele.FontSize = 54;
                                            break;
                                        case 22:
                                            tekstLabele.FontSize = 56;
                                            break;
                                        case 23:
                                            tekstLabele.FontSize = 58;
                                            break;
                                        case 24:
                                            tekstLabele.FontSize = 60;
                                            break;
                                    }
                                    labela.Content = tekstLabele;



                                }

                            }

                        }

                        //kod za stampapanje i konvertovanje prozora u PDF
                        PrintDialog printDlg = new PrintDialog();

                        // Specify the printer by name (in this case, "Microsoft Print to PDF")
                        printDlg.PrintQueue = new PrintQueue(new PrintServer(), "Microsoft Print to PDF");

                        PageMediaSize pageSize = new PageMediaSize(PageMediaSizeName.ISOA4);
                        printDlg.PrintTicket.PageMediaSize = pageSize;

                        if (printDlg.ShowDialog() == true)
                        {
                            printDlg.PrintVisual(stampanjeSablona.noviSablonGrid, "Testiranje");
                        }
                        PrintTicket pt = printDlg.PrintTicket;
                    }
                    if (proizvoljneNalepnice.IsChecked == true)
                    {
                        int prvaNalepnicaKolicina = Convert.ToInt32(prvaNalepnica_text.Text);
                        int zadnjaNalepnicaKolicina = Convert.ToInt32(zadnjaNalepnica_text.Text);

                        if (zadnjaNalepnicaKolicina < prvaNalepnicaKolicina)
                        {
                            MessageBox.Show("Zadnja nalepnica ne može biti pre prve nalepnice", "Greška", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                        else
                        {
                            //MessageBox.Show("Izabrali ste proizvoljnu kolicinu", "Broj btn po visini", MessageBoxButton.OK, MessageBoxImage.Information);
                            //MessageBox.Show(prvaNalepnicaKolicina.ToString(), "Prva nalepnica", MessageBoxButton.OK, MessageBoxImage.Information);
                            //MessageBox.Show(zadnjaNalepnicaKolicina.ToString(), "Zadnja nalepnica", MessageBoxButton.OK, MessageBoxImage.Information);


                            for (int j = 0; j < kolicinaNalepnicaPoVisini + (kolicinaNalepnicaPoVisini - 1); j++)
                            {
                                //petlja za vertikalni razmak
                                if (j % 2 == 1)
                                {
                                    RowDefinition redRazmak = new RowDefinition();
                                    redRazmak.Height = new GridLength(ConvertCmToPixels(razmakVertikalni));
                                    stampanjeSablona.noviSablonGrid.RowDefinitions.Add(redRazmak);
                                }
                                //petlja za pravljenje redova
                                if (j % 2 == 0)
                                {
                                    RowDefinition red = new RowDefinition();
                                    red.Height = new GridLength(ConvertCmToPixels(visinaNalepnice));
                                    stampanjeSablona.noviSablonGrid.RowDefinitions.Add(red);
                                }



                                for (int i = 0; i < kolicinaNalepnicaPoDuzini + (kolicinaNalepnicaPoDuzini - 1); i++)
                                {

                                    //petlja za horizontalni razmak
                                    if (i % 2 == 1)
                                    {
                                        ColumnDefinition kolonaRazmak = new ColumnDefinition();
                                        kolonaRazmak.Width = new GridLength(ConvertCmToPixels(razmakHorizontalni));
                                        stampanjeSablona.noviSablonGrid.ColumnDefinitions.Add(kolonaRazmak);
                                    }


                                    //petlja za pravljenje kolona i dugmadi
                                    if (i % 2 == 0 && j % 2 == 0)
                                    {
                                        ColumnDefinition kolona = new ColumnDefinition();
                                        kolona.Width = new GridLength(ConvertCmToPixels(sirinaNalepnice));
                                        stampanjeSablona.noviSablonGrid.ColumnDefinitions.Add(kolona);


                                        String imeNalepnice = "nalepnica" + brojac;




                                        if (brojac >= prvaNalepnicaKolicina && brojac <= zadnjaNalepnicaKolicina)
                                        {
                                            //pravljenje izgleda nalepnice
                                            Button dugme = new Button();
                                            dugme.Background = Brushes.Transparent;
                                            dugme.BorderThickness = new Thickness(1);
                                            stampanjeSablona.noviSablonGrid.Children.Add(dugme);
                                            Grid.SetRow(dugme, j);
                                            Grid.SetColumn(dugme, i);

                                            Label labela = new Label();
                                            labela.HorizontalContentAlignment = HorizontalAlignment.Center;
                                            labela.VerticalContentAlignment = VerticalAlignment.Center;
                                            stampanjeSablona.noviSablonGrid.Children.Add(labela);
                                            Grid.SetRow(labela, j);
                                            Grid.SetColumn(labela, i);

                                            TextBlock tekstLabele = new TextBlock();
                                            tekstLabele.TextWrapping = TextWrapping.Wrap;
                                            tekstLabele.TextAlignment = TextAlignment.Center;
                                            tekstLabele.Text = nalepnicaSadrzaj.Text;

                                            switch (velicinaFonta.SelectedIndex)
                                            {
                                                case 0:
                                                    tekstLabele.FontSize = 12;
                                                    break;
                                                case 1:
                                                    tekstLabele.FontSize = 14;
                                                    break;
                                                case 2:
                                                    tekstLabele.FontSize = 16;
                                                    break;
                                                case 3:
                                                    tekstLabele.FontSize = 18;
                                                    break;
                                                case 4:
                                                    tekstLabele.FontSize = 20;
                                                    break;
                                                case 5:
                                                    tekstLabele.FontSize = 22;
                                                    break;
                                                case 6:
                                                    tekstLabele.FontSize = 24;
                                                    break;
                                                case 7:
                                                    tekstLabele.FontSize = 26;
                                                    break;
                                                case 8:
                                                    tekstLabele.FontSize = 28;
                                                    break;
                                                case 9:
                                                    tekstLabele.FontSize = 30;
                                                    break;
                                                case 10:
                                                    tekstLabele.FontSize = 32;
                                                    break;
                                                case 11:
                                                    tekstLabele.FontSize = 34;
                                                    break;
                                                case 12:
                                                    tekstLabele.FontSize = 36;
                                                    break;
                                                case 13:
                                                    tekstLabele.FontSize = 38;
                                                    break;
                                                case 14:
                                                    tekstLabele.FontSize = 40;
                                                    break;
                                                case 15:
                                                    tekstLabele.FontSize = 42;
                                                    break;
                                                case 16:
                                                    tekstLabele.FontSize = 44;
                                                    break;
                                                case 17:
                                                    tekstLabele.FontSize = 46;
                                                    break;
                                                case 18:
                                                    tekstLabele.FontSize = 48;
                                                    break;
                                                case 19:
                                                    tekstLabele.FontSize = 50;
                                                    break;
                                                case 20:
                                                    tekstLabele.FontSize = 52;
                                                    break;
                                                case 21:
                                                    tekstLabele.FontSize = 54;
                                                    break;
                                                case 22:
                                                    tekstLabele.FontSize = 56;
                                                    break;
                                                case 23:
                                                    tekstLabele.FontSize = 58;
                                                    break;
                                                case 24:
                                                    tekstLabele.FontSize = 60;
                                                    break;
                                            }
                                            labela.Content = tekstLabele;


                                        }

                                        brojac++;


                                    }

                                }

                            }

                            //kod za stampapanje i konvertovanje prozora u PDF
                            PrintDialog printDlg = new PrintDialog();

                            // Specify the printer by name (in this case, "Microsoft Print to PDF")
                            printDlg.PrintQueue = new PrintQueue(new PrintServer(), "Microsoft Print to PDF");

                            PageMediaSize pageSize = new PageMediaSize(PageMediaSizeName.ISOA4);
                            printDlg.PrintTicket.PageMediaSize = pageSize;

                            if (printDlg.ShowDialog() == true)
                            {
                                printDlg.PrintVisual(stampanjeSablona.noviSablonGrid, "Testiranje");
                            }
                            PrintTicket pt = printDlg.PrintTicket;
                        }



                    }
                    if (jednaNalepnica.IsChecked == true)
                    {
                        int prvaNalepnicaKolicina = Convert.ToInt32(prvaNalepnica_text.Text);
                        for (int j = 0; j < kolicinaNalepnicaPoVisini + (kolicinaNalepnicaPoVisini - 1); j++)
                        {
                            //petlja za vertikalni razmak
                            if (j % 2 == 1)
                            {
                                RowDefinition redRazmak = new RowDefinition();
                                redRazmak.Height = new GridLength(ConvertCmToPixels(razmakVertikalni));
                                stampanjeSablona.noviSablonGrid.RowDefinitions.Add(redRazmak);
                            }
                            //petlja za pravljenje redova
                            if (j % 2 == 0)
                            {
                                RowDefinition red = new RowDefinition();
                                red.Height = new GridLength(ConvertCmToPixels(visinaNalepnice));
                                stampanjeSablona.noviSablonGrid.RowDefinitions.Add(red);
                            }



                            for (int i = 0; i < kolicinaNalepnicaPoDuzini + (kolicinaNalepnicaPoDuzini - 1); i++)
                            {

                                //petlja za horizontalni razmak
                                if (i % 2 == 1)
                                {
                                    ColumnDefinition kolonaRazmak = new ColumnDefinition();
                                    kolonaRazmak.Width = new GridLength(ConvertCmToPixels(razmakHorizontalni));
                                    stampanjeSablona.noviSablonGrid.ColumnDefinitions.Add(kolonaRazmak);
                                }


                                //petlja za pravljenje kolona i dugmadi
                                if (i % 2 == 0 && j % 2 == 0)
                                {
                                    ColumnDefinition kolona = new ColumnDefinition();
                                    kolona.Width = new GridLength(ConvertCmToPixels(sirinaNalepnice));
                                    stampanjeSablona.noviSablonGrid.ColumnDefinitions.Add(kolona);


                                    String imeNalepnice = "nalepnica" + brojac;




                                    if (brojac == prvaNalepnicaKolicina)
                                    {
                                        //pravljenje izgleda nalepnice
                                        Button dugme = new Button();
                                        dugme.Background = Brushes.Transparent;
                                        dugme.BorderThickness = new Thickness(1);
                                        stampanjeSablona.noviSablonGrid.Children.Add(dugme);
                                        Grid.SetRow(dugme, j);
                                        Grid.SetColumn(dugme, i);

                                        Label labela = new Label();
                                        labela.HorizontalContentAlignment = HorizontalAlignment.Center;
                                        labela.VerticalContentAlignment = VerticalAlignment.Center;
                                        stampanjeSablona.noviSablonGrid.Children.Add(labela);
                                        Grid.SetRow(labela, j);
                                        Grid.SetColumn(labela, i);

                                        TextBlock tekstLabele = new TextBlock();
                                        tekstLabele.TextWrapping = TextWrapping.Wrap;
                                        tekstLabele.TextAlignment = TextAlignment.Center;
                                        tekstLabele.Text = nalepnicaSadrzaj.Text;

                                        switch (velicinaFonta.SelectedIndex)
                                        {
                                            case 0:
                                                tekstLabele.FontSize = 12;
                                                break;
                                            case 1:
                                                tekstLabele.FontSize = 14;
                                                break;
                                            case 2:
                                                tekstLabele.FontSize = 16;
                                                break;
                                            case 3:
                                                tekstLabele.FontSize = 18;
                                                break;
                                            case 4:
                                                tekstLabele.FontSize = 20;
                                                break;
                                            case 5:
                                                tekstLabele.FontSize = 22;
                                                break;
                                            case 6:
                                                tekstLabele.FontSize = 24;
                                                break;
                                            case 7:
                                                tekstLabele.FontSize = 26;
                                                break;
                                            case 8:
                                                tekstLabele.FontSize = 28;
                                                break;
                                            case 9:
                                                tekstLabele.FontSize = 30;
                                                break;
                                            case 10:
                                                tekstLabele.FontSize = 32;
                                                break;
                                            case 11:
                                                tekstLabele.FontSize = 34;
                                                break;
                                            case 12:
                                                tekstLabele.FontSize = 36;
                                                break;
                                            case 13:
                                                tekstLabele.FontSize = 38;
                                                break;
                                            case 14:
                                                tekstLabele.FontSize = 40;
                                                break;
                                            case 15:
                                                tekstLabele.FontSize = 42;
                                                break;
                                            case 16:
                                                tekstLabele.FontSize = 44;
                                                break;
                                            case 17:
                                                tekstLabele.FontSize = 46;
                                                break;
                                            case 18:
                                                tekstLabele.FontSize = 48;
                                                break;
                                            case 19:
                                                tekstLabele.FontSize = 50;
                                                break;
                                            case 20:
                                                tekstLabele.FontSize = 52;
                                                break;
                                            case 21:
                                                tekstLabele.FontSize = 54;
                                                break;
                                            case 22:
                                                tekstLabele.FontSize = 56;
                                                break;
                                            case 23:
                                                tekstLabele.FontSize = 58;
                                                break;
                                            case 24:
                                                tekstLabele.FontSize = 60;
                                                break;
                                        }
                                        labela.Content = tekstLabele;


                                    }

                                    brojac++;


                                }

                            }

                        }

                        //kod za stampapanje i konvertovanje prozora u PDF
                        PrintDialog printDlg = new PrintDialog();

                        // Specify the printer by name (in this case, "Microsoft Print to PDF")
                        printDlg.PrintQueue = new PrintQueue(new PrintServer(), "Microsoft Print to PDF");

                        PageMediaSize pageSize = new PageMediaSize(PageMediaSizeName.ISOA4);
                        printDlg.PrintTicket.PageMediaSize = pageSize;

                        if (printDlg.ShowDialog() == true)
                        {
                            printDlg.PrintVisual(stampanjeSablona.noviSablonGrid, "Testiranje");
                        }
                        PrintTicket pt = printDlg.PrintTicket;
                    }
                }
            }
            else
            {
                if (nalepnicaSirina.Text == "0" || nalepnicaVisina.Text == "0" || nalepnicaSadrzaj.Text == "")
                {
                    MessageBox.Show("Unesite dimenzije nalepnica", "Greška", MessageBoxButton.OK, MessageBoxImage.Error);

                }
                else
                {
                    int brojac = 1;
                    StampanjeSablona stampanjeSablona = new StampanjeSablona();

                    //stavljanje unetih margina na prozor
                    stampanjeSablona.noviSablonGrid.Margin = new Thickness(ConvertCmToPixels(levaMargina), ConvertCmToPixels(gornjaMargina), ConvertCmToPixels(desnaMargina), ConvertCmToPixels(donjaMargina));
                    if (sveNalepnice.IsChecked == true)
                    {
                        for (int j = 0; j < kolicinaNalepnicaPoVisini + (kolicinaNalepnicaPoVisini - 1); j++)
                        {
                            //petlja za vertikalni razmak
                            if (j % 2 == 1)
                            {
                                RowDefinition redRazmak = new RowDefinition();
                                redRazmak.Height = new GridLength(ConvertCmToPixels(razmakVertikalni));
                                stampanjeSablona.noviSablonGrid.RowDefinitions.Add(redRazmak);
                            }
                            //petlja za pravljenje redova
                            if (j % 2 == 0)
                            {
                                RowDefinition red = new RowDefinition();
                                red.Height = new GridLength(ConvertCmToPixels(visinaNalepnice));
                                stampanjeSablona.noviSablonGrid.RowDefinitions.Add(red);
                            }



                            for (int i = 0; i < kolicinaNalepnicaPoDuzini + (kolicinaNalepnicaPoDuzini - 1); i++)
                            {
                                //petlja za horizontalni razmak
                                if (i % 2 == 1)
                                {
                                    ColumnDefinition kolonaRazmak = new ColumnDefinition();
                                    kolonaRazmak.Width = new GridLength(ConvertCmToPixels(razmakHorizontalni));
                                    stampanjeSablona.noviSablonGrid.ColumnDefinitions.Add(kolonaRazmak);
                                }


                                //petlja za pravljenje kolona i dugmadi
                                if (i % 2 == 0 && j % 2 == 0)
                                {
                                    ColumnDefinition kolona = new ColumnDefinition();
                                    kolona.Width = new GridLength(ConvertCmToPixels(sirinaNalepnice));
                                    stampanjeSablona.noviSablonGrid.ColumnDefinitions.Add(kolona);

                                    //String imeNalepnice = "nalepnica" + i;
                                    //pravljenje izgleda nalepnice
                                    Button dugme = new Button();
                                    dugme.Background = Brushes.Transparent;
                                    dugme.BorderBrush = Brushes.Transparent;
                                    Grid.SetRow(dugme, j);
                                    Grid.SetColumn(dugme, i);
                                    stampanjeSablona.noviSablonGrid.Children.Add(dugme);


                                    Label labela = new Label();
                                    labela.HorizontalContentAlignment = HorizontalAlignment.Center;
                                    labela.VerticalContentAlignment = VerticalAlignment.Center;
                                    Grid.SetRow(labela, j);
                                    Grid.SetColumn(labela, i);
                                    stampanjeSablona.noviSablonGrid.Children.Add(labela);

                                    TextBlock tekstLabele = new TextBlock();
                                    tekstLabele.TextWrapping = TextWrapping.Wrap;
                                    tekstLabele.TextAlignment = TextAlignment.Center;
                                    tekstLabele.Text = nalepnicaSadrzaj.Text;
                                    switch (velicinaFonta.SelectedIndex)
                                    {
                                        case 0:
                                            tekstLabele.FontSize = 12;
                                            break;
                                        case 1:
                                            tekstLabele.FontSize = 14;
                                            break;
                                        case 2:
                                            tekstLabele.FontSize = 16;
                                            break;
                                        case 3:
                                            tekstLabele.FontSize = 18;
                                            break;
                                        case 4:
                                            tekstLabele.FontSize = 20;
                                            break;
                                        case 5:
                                            tekstLabele.FontSize = 22;
                                            break;
                                        case 6:
                                            tekstLabele.FontSize = 24;
                                            break;
                                        case 7:
                                            tekstLabele.FontSize = 26;
                                            break;
                                        case 8:
                                            tekstLabele.FontSize = 28;
                                            break;
                                        case 9:
                                            tekstLabele.FontSize = 30;
                                            break;
                                        case 10:
                                            tekstLabele.FontSize = 32;
                                            break;
                                        case 11:
                                            tekstLabele.FontSize = 34;
                                            break;
                                        case 12:
                                            tekstLabele.FontSize = 36;
                                            break;
                                        case 13:
                                            tekstLabele.FontSize = 38;
                                            break;
                                        case 14:
                                            tekstLabele.FontSize = 40;
                                            break;
                                        case 15:
                                            tekstLabele.FontSize = 42;
                                            break;
                                        case 16:
                                            tekstLabele.FontSize = 44;
                                            break;
                                        case 17:
                                            tekstLabele.FontSize = 46;
                                            break;
                                        case 18:
                                            tekstLabele.FontSize = 48;
                                            break;
                                        case 19:
                                            tekstLabele.FontSize = 50;
                                            break;
                                        case 20:
                                            tekstLabele.FontSize = 52;
                                            break;
                                        case 21:
                                            tekstLabele.FontSize = 54;
                                            break;
                                        case 22:
                                            tekstLabele.FontSize = 56;
                                            break;
                                        case 23:
                                            tekstLabele.FontSize = 58;
                                            break;
                                        case 24:
                                            tekstLabele.FontSize = 60;
                                            break;
                                    }
                                    labela.Content = tekstLabele;



                                }

                            }

                        }

                        //kod za stampapanje i konvertovanje prozora u PDF
                        PrintDialog printDlg = new PrintDialog();

                        // Specify the printer by name (in this case, "Microsoft Print to PDF")
                        printDlg.PrintQueue = new PrintQueue(new PrintServer(), "Microsoft Print to PDF");

                        PageMediaSize pageSize = new PageMediaSize(PageMediaSizeName.ISOA4);
                        printDlg.PrintTicket.PageMediaSize = pageSize;

                        if (printDlg.ShowDialog() == true)
                        {
                            printDlg.PrintVisual(stampanjeSablona.noviSablonGrid, "Testiranje");
                        }
                        PrintTicket pt = printDlg.PrintTicket;
                    }
                    if (proizvoljneNalepnice.IsChecked == true)
                    {
                        int prvaNalepnicaKolicina = Convert.ToInt32(prvaNalepnica_text.Text);
                        int zadnjaNalepnicaKolicina = Convert.ToInt32(zadnjaNalepnica_text.Text);

                        if (zadnjaNalepnicaKolicina < prvaNalepnicaKolicina)
                        {
                            MessageBox.Show("Zadnja nalepnica ne može biti pre prve nalepnice", "Greška", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                        else
                        {
                            //MessageBox.Show("Izabrali ste proizvoljnu kolicinu", "Broj btn po visini", MessageBoxButton.OK, MessageBoxImage.Information);
                            //MessageBox.Show(prvaNalepnicaKolicina.ToString(), "Prva nalepnica", MessageBoxButton.OK, MessageBoxImage.Information);
                            //MessageBox.Show(zadnjaNalepnicaKolicina.ToString(), "Zadnja nalepnica", MessageBoxButton.OK, MessageBoxImage.Information);


                            for (int j = 0; j < kolicinaNalepnicaPoVisini + (kolicinaNalepnicaPoVisini - 1); j++)
                            {
                                //petlja za vertikalni razmak
                                if (j % 2 == 1)
                                {
                                    RowDefinition redRazmak = new RowDefinition();
                                    redRazmak.Height = new GridLength(ConvertCmToPixels(razmakVertikalni));
                                    stampanjeSablona.noviSablonGrid.RowDefinitions.Add(redRazmak);
                                }
                                //petlja za pravljenje redova
                                if (j % 2 == 0)
                                {
                                    RowDefinition red = new RowDefinition();
                                    red.Height = new GridLength(ConvertCmToPixels(visinaNalepnice));
                                    stampanjeSablona.noviSablonGrid.RowDefinitions.Add(red);
                                }



                                for (int i = 0; i < kolicinaNalepnicaPoDuzini + (kolicinaNalepnicaPoDuzini - 1); i++)
                                {

                                    //petlja za horizontalni razmak
                                    if (i % 2 == 1)
                                    {
                                        ColumnDefinition kolonaRazmak = new ColumnDefinition();
                                        kolonaRazmak.Width = new GridLength(ConvertCmToPixels(razmakHorizontalni));
                                        stampanjeSablona.noviSablonGrid.ColumnDefinitions.Add(kolonaRazmak);
                                    }


                                    //petlja za pravljenje kolona i dugmadi
                                    if (i % 2 == 0 && j % 2 == 0)
                                    {
                                        ColumnDefinition kolona = new ColumnDefinition();
                                        kolona.Width = new GridLength(ConvertCmToPixels(sirinaNalepnice));
                                        stampanjeSablona.noviSablonGrid.ColumnDefinitions.Add(kolona);


                                        String imeNalepnice = "nalepnica" + brojac;




                                        if (brojac >= prvaNalepnicaKolicina && brojac <= zadnjaNalepnicaKolicina)
                                        {
                                            //pravljenje izgleda nalepnice
                                            Button dugme = new Button();
                                            dugme.Background = Brushes.Transparent;
                                            dugme.BorderBrush = Brushes.Transparent;
                                            stampanjeSablona.noviSablonGrid.Children.Add(dugme);
                                            Grid.SetRow(dugme, j);
                                            Grid.SetColumn(dugme, i);

                                            Label labela = new Label();
                                            labela.HorizontalContentAlignment = HorizontalAlignment.Center;
                                            labela.VerticalContentAlignment = VerticalAlignment.Center;
                                            stampanjeSablona.noviSablonGrid.Children.Add(labela);
                                            Grid.SetRow(labela, j);
                                            Grid.SetColumn(labela, i);

                                            TextBlock tekstLabele = new TextBlock();
                                            tekstLabele.TextWrapping = TextWrapping.Wrap;
                                            tekstLabele.TextAlignment = TextAlignment.Center;
                                            tekstLabele.Text = nalepnicaSadrzaj.Text;

                                            switch (velicinaFonta.SelectedIndex)
                                            {
                                                case 0:
                                                    tekstLabele.FontSize = 12;
                                                    break;
                                                case 1:
                                                    tekstLabele.FontSize = 14;
                                                    break;
                                                case 2:
                                                    tekstLabele.FontSize = 16;
                                                    break;
                                                case 3:
                                                    tekstLabele.FontSize = 18;
                                                    break;
                                                case 4:
                                                    tekstLabele.FontSize = 20;
                                                    break;
                                                case 5:
                                                    tekstLabele.FontSize = 22;
                                                    break;
                                                case 6:
                                                    tekstLabele.FontSize = 24;
                                                    break;
                                                case 7:
                                                    tekstLabele.FontSize = 26;
                                                    break;
                                                case 8:
                                                    tekstLabele.FontSize = 28;
                                                    break;
                                                case 9:
                                                    tekstLabele.FontSize = 30;
                                                    break;
                                                case 10:
                                                    tekstLabele.FontSize = 32;
                                                    break;
                                                case 11:
                                                    tekstLabele.FontSize = 34;
                                                    break;
                                                case 12:
                                                    tekstLabele.FontSize = 36;
                                                    break;
                                                case 13:
                                                    tekstLabele.FontSize = 38;
                                                    break;
                                                case 14:
                                                    tekstLabele.FontSize = 40;
                                                    break;
                                                case 15:
                                                    tekstLabele.FontSize = 42;
                                                    break;
                                                case 16:
                                                    tekstLabele.FontSize = 44;
                                                    break;
                                                case 17:
                                                    tekstLabele.FontSize = 46;
                                                    break;
                                                case 18:
                                                    tekstLabele.FontSize = 48;
                                                    break;
                                                case 19:
                                                    tekstLabele.FontSize = 50;
                                                    break;
                                                case 20:
                                                    tekstLabele.FontSize = 52;
                                                    break;
                                                case 21:
                                                    tekstLabele.FontSize = 54;
                                                    break;
                                                case 22:
                                                    tekstLabele.FontSize = 56;
                                                    break;
                                                case 23:
                                                    tekstLabele.FontSize = 58;
                                                    break;
                                                case 24:
                                                    tekstLabele.FontSize = 60;
                                                    break;
                                            }
                                            labela.Content = tekstLabele;


                                        }

                                        brojac++;


                                    }

                                }

                            }

                            //kod za stampapanje i konvertovanje prozora u PDF
                            PrintDialog printDlg = new PrintDialog();

                            // Specify the printer by name (in this case, "Microsoft Print to PDF")
                            printDlg.PrintQueue = new PrintQueue(new PrintServer(), "Microsoft Print to PDF");

                            PageMediaSize pageSize = new PageMediaSize(PageMediaSizeName.ISOA4);
                            printDlg.PrintTicket.PageMediaSize = pageSize;

                            if (printDlg.ShowDialog() == true)
                            {
                                printDlg.PrintVisual(stampanjeSablona.noviSablonGrid, "Testiranje");
                            }
                            PrintTicket pt = printDlg.PrintTicket;
                        }



                    }
                    if (jednaNalepnica.IsChecked == true)
                    {
                        int prvaNalepnicaKolicina = Convert.ToInt32(prvaNalepnica_text.Text);
                        for (int j = 0; j < kolicinaNalepnicaPoVisini + (kolicinaNalepnicaPoVisini - 1); j++)
                        {
                            //petlja za vertikalni razmak
                            if (j % 2 == 1)
                            {
                                RowDefinition redRazmak = new RowDefinition();
                                redRazmak.Height = new GridLength(ConvertCmToPixels(razmakVertikalni));
                                stampanjeSablona.noviSablonGrid.RowDefinitions.Add(redRazmak);
                            }
                            //petlja za pravljenje redova
                            if (j % 2 == 0)
                            {
                                RowDefinition red = new RowDefinition();
                                red.Height = new GridLength(ConvertCmToPixels(visinaNalepnice));
                                stampanjeSablona.noviSablonGrid.RowDefinitions.Add(red);
                            }



                            for (int i = 0; i < kolicinaNalepnicaPoDuzini + (kolicinaNalepnicaPoDuzini - 1); i++)
                            {

                                //petlja za horizontalni razmak
                                if (i % 2 == 1)
                                {
                                    ColumnDefinition kolonaRazmak = new ColumnDefinition();
                                    kolonaRazmak.Width = new GridLength(ConvertCmToPixels(razmakHorizontalni));
                                    stampanjeSablona.noviSablonGrid.ColumnDefinitions.Add(kolonaRazmak);
                                }


                                //petlja za pravljenje kolona i dugmadi
                                if (i % 2 == 0 && j % 2 == 0)
                                {
                                    ColumnDefinition kolona = new ColumnDefinition();
                                    kolona.Width = new GridLength(ConvertCmToPixels(sirinaNalepnice));
                                    stampanjeSablona.noviSablonGrid.ColumnDefinitions.Add(kolona);


                                    String imeNalepnice = "nalepnica" + brojac;




                                    if (brojac == prvaNalepnicaKolicina)
                                    {
                                        //pravljenje izgleda nalepnice
                                        Button dugme = new Button();
                                        dugme.Background = Brushes.Transparent;
                                        dugme.BorderBrush = Brushes.Transparent;
                                        stampanjeSablona.noviSablonGrid.Children.Add(dugme);
                                        Grid.SetRow(dugme, j);
                                        Grid.SetColumn(dugme, i);

                                        Label labela = new Label();
                                        labela.HorizontalContentAlignment = HorizontalAlignment.Center;
                                        labela.VerticalContentAlignment = VerticalAlignment.Center;
                                        stampanjeSablona.noviSablonGrid.Children.Add(labela);
                                        Grid.SetRow(labela, j);
                                        Grid.SetColumn(labela, i);

                                        TextBlock tekstLabele = new TextBlock();
                                        tekstLabele.TextWrapping = TextWrapping.Wrap;
                                        tekstLabele.TextAlignment = TextAlignment.Center;
                                        tekstLabele.Text = nalepnicaSadrzaj.Text;

                                        switch (velicinaFonta.SelectedIndex)
                                        {
                                            case 0:
                                                tekstLabele.FontSize = 12;
                                                break;
                                            case 1:
                                                tekstLabele.FontSize = 14;
                                                break;
                                            case 2:
                                                tekstLabele.FontSize = 16;
                                                break;
                                            case 3:
                                                tekstLabele.FontSize = 18;
                                                break;
                                            case 4:
                                                tekstLabele.FontSize = 20;
                                                break;
                                            case 5:
                                                tekstLabele.FontSize = 22;
                                                break;
                                            case 6:
                                                tekstLabele.FontSize = 24;
                                                break;
                                            case 7:
                                                tekstLabele.FontSize = 26;
                                                break;
                                            case 8:
                                                tekstLabele.FontSize = 28;
                                                break;
                                            case 9:
                                                tekstLabele.FontSize = 30;
                                                break;
                                            case 10:
                                                tekstLabele.FontSize = 32;
                                                break;
                                            case 11:
                                                tekstLabele.FontSize = 34;
                                                break;
                                            case 12:
                                                tekstLabele.FontSize = 36;
                                                break;
                                            case 13:
                                                tekstLabele.FontSize = 38;
                                                break;
                                            case 14:
                                                tekstLabele.FontSize = 40;
                                                break;
                                            case 15:
                                                tekstLabele.FontSize = 42;
                                                break;
                                            case 16:
                                                tekstLabele.FontSize = 44;
                                                break;
                                            case 17:
                                                tekstLabele.FontSize = 46;
                                                break;
                                            case 18:
                                                tekstLabele.FontSize = 48;
                                                break;
                                            case 19:
                                                tekstLabele.FontSize = 50;
                                                break;
                                            case 20:
                                                tekstLabele.FontSize = 52;
                                                break;
                                            case 21:
                                                tekstLabele.FontSize = 54;
                                                break;
                                            case 22:
                                                tekstLabele.FontSize = 56;
                                                break;
                                            case 23:
                                                tekstLabele.FontSize = 58;
                                                break;
                                            case 24:
                                                tekstLabele.FontSize = 60;
                                                break;
                                        }
                                        labela.Content = tekstLabele;


                                    }

                                    brojac++;


                                }

                            }

                        }

                        //kod za stampapanje i konvertovanje prozora u PDF
                        PrintDialog printDlg = new PrintDialog();

                        // Specify the printer by name (in this case, "Microsoft Print to PDF")
                        printDlg.PrintQueue = new PrintQueue(new PrintServer(), "Microsoft Print to PDF");

                        PageMediaSize pageSize = new PageMediaSize(PageMediaSizeName.ISOA4);
                        printDlg.PrintTicket.PageMediaSize = pageSize;

                        if (printDlg.ShowDialog() == true)
                        {
                            printDlg.PrintVisual(stampanjeSablona.noviSablonGrid, "Testiranje");
                        }
                        PrintTicket pt = printDlg.PrintTicket;
                    }
                }
            }
        }


        private void TextBox_Regex(object sender, System.Windows.Input.TextCompositionEventArgs e)
        {
            // povlacenje unesenog teksta
            TextBox textBox = (TextBox)sender;

            // proverava da li je unos tekst
            if (!DozvoljenUnos(e.Text))
            {
                // cancel input ako ima teksta
                e.Handled = true;
            }
        }
        private bool DozvoljenUnos(string text)
        {
            // regex
            string pattern = @"^[0-9]*(\.[0-9]*)?$";
            Regex regex = new Regex(pattern);

            // proverava da li input odgovara regexu
            return regex.IsMatch(text);
        }

        private double KolicinaNalepnica()
        {
            //konvertovanje unetih vrednosti iz cm u px
            levaMargina = Convert.ToDouble(marginaLeva.Text);
            gornjaMargina = Convert.ToDouble(marginaGornja.Text);
            desnaMargina = Convert.ToDouble(marginaDesna.Text);
            donjaMargina = Convert.ToDouble(marginaDonja.Text);
            sirinaNalepnice = Convert.ToDouble(nalepnicaSirina.Text);
            visinaNalepnice = Convert.ToDouble(nalepnicaVisina.Text);
            razmakHorizontalni = Convert.ToDouble(horizontalniRazmak.Text);
            razmakVertikalni = Convert.ToDouble(vertikalniRazmak.Text);

            //izracunavanje slobodnog prostora nakon margina
            novaSirinaA4 = SIRINA_A4 - (levaMargina + desnaMargina);
            novaVisinaA4 = VISINA_A4 - (gornjaMargina + donjaMargina);

            //petlja za izracunavanje nalepnica po duzini

            while (privremenaDuzina <= novaSirinaA4)
            {
                privremenaDuzina += sirinaNalepnice + razmakHorizontalni;
                kolicinaNalepnicaPoDuzini++;

                if (privremenaDuzina + sirinaNalepnice > novaSirinaA4)
                {
                    break;
                }

            }

            //petlja za izracunavanje nalepnica po visini


            while (privremenaVisina <= novaVisinaA4)
            {
                privremenaVisina += visinaNalepnice + razmakVertikalni;
                kolicinaNalepnicaPoVisini++;

                if (privremenaVisina + visinaNalepnice > novaVisinaA4)
                {
                    break;
                }

            }

            ukupanBrojNalepnica = kolicinaNalepnicaPoDuzini * kolicinaNalepnicaPoVisini;
            return ukupanBrojNalepnica;

        }
        private double ConvertCmToPixels(double cm)
        {

            PresentationSource source = PresentationSource.FromVisual(this);
            double dpiX = 96.0;

            if (source != null)
            {
                dpiX = 96.0 * source.CompositionTarget.TransformToDevice.M11;
            }

            double pixels = (cm / 2.54) * dpiX;
            return pixels;
        }
        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);

            Application.Current.Shutdown();
        }
    }
}
